import { Injectable } from '@angular/core';
import { ToastController, MenuController } from '@ionic/angular';

@Injectable()

export class GlobalService {
  appPages: any;
  activeUser: any;

  constructor(
    private toastCtrl: ToastController,
    private menuCtrl: MenuController
  ) {
    this.sidemenu();
  }

  menuEnable(){
    this.menuCtrl.enable(true);
  }

  menuDisable(){
    this.menuCtrl.enable(false);
  }

  async presentToast(msg, dur) {
		const toast = await this.toastCtrl.create({
		  message: msg,
		  duration: dur
		});
    
		toast.present();
	}

  sidemenu(){
    this.appPages = [
      { title: 'My Account', url: 'myProfile', icon: 'person-circle' },
      { title: 'Logout', url: 'logout', icon: 'log-out' }
    ]
  }
}
