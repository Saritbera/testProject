import { HttpHeaders } from '@angular/common/http';

export const emailPattern = /^\w+[a-z0-9._]+@+[a-z.]+\.[a-z]{2,3}$/;
// export const phonePattern = /^[7-9][0-9]{9}$/;
// export const numberPattern = /^[0-9]$/;
// export const namePattern = /^[A-Za-z]$/;
// export const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,15}$/;

export const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':'application/json',
      'Access-Control-Allow-Methods': 'GET, POST',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With'
    })
};