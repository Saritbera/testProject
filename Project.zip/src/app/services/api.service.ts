import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { httpOptions } from '../services/constant.service';

@Injectable()

export class ApiService {

  constructor(
    private http: HttpClient
  ) { }

  post(funpoint, obj) {
    var url = environment.apiendpoint+funpoint; 
    return this.http.post(url, obj, httpOptions); // for dot net
  }

  get(funpoint: string, isobj: boolean, obj?: any){
    var url;  
    url = environment.apiendpoint+funpoint;

    if (isobj) {        
      url += this.buildParams(obj);
    }   

    return this.http.get(url, httpOptions); // for dot net
  }

  delete(funpoint: string, obj: any){
    var url;  
    url = environment.apiendpoint+funpoint;
    url += this.buildParams(obj);
    return this.http.delete(url, httpOptions); // for dot net
  }

  buildParams(params): string {
    var keys = Object.keys( params );
    var values = Object.values( params );
    if(keys.length == 0) return '';
    var stringParams = '?';
    for(let i = 0; i < keys.length; i++){
      stringParams += keys[i] + '=' + values[i];
      if(i != keys.length-1) stringParams += '&';
    }
    return stringParams;
  }
}
