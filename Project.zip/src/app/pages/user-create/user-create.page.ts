import { Component, OnInit } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';
import { GlobalService } from 'src/app/services/global.service';

@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.page.html',
  styleUrls: ['./user-create.page.scss'],
})
export class UserCreatePage implements OnInit {
  userData = {
    "name": "",
    "job": ""
  };
  
  constructor(
    private popOverCtrl: PopoverController,
    private apiCtrl: ApiService,
    private globalCtrl: GlobalService
  ) { }

  ngOnInit() {
  }

  closePopover(){
		this.popOverCtrl.dismiss();
	}

  addUser(){
    var obj = {
      "name": this.userData.name,
      "job": this.userData.job
    }

    console.log(obj)

    var func, objOption, res, response;
    func = 'users';
    
    this.apiCtrl.post(func, obj).subscribe((data)=> {
      console.log(data);
      this.closePopover();
      this.globalCtrl.presentToast('New User Added!!!', 2000)
    }, (err) => {
      this.globalCtrl.presentToast(err, 2000);
    });
  }

}
