import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { GlobalService } from 'src/app/services/global.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.page.html',
  styleUrls: ['./user-list.page.scss'],
})
export class UserListPage implements OnInit {
  userres: any;
  constructor(
    private apiCtrl: ApiService,
    private globalCtrl: GlobalService
  ) {    
    this.getUser();
  }

  ngOnInit() {
  }

  ionViewWillEnter(){
    this.getUser();
  }

  getUser(){
    var func, objOption, res, response, obj;
    func = 'users';
    objOption = true;
    obj = {
      "page": "2"
    }
    
    this.apiCtrl.get(func, objOption, obj).subscribe((data)=> {
      res = data;
      response = res.data;
      this.userres = response;
    }, (err) => {
      this.globalCtrl.presentToast(err, 2000);
    });
  } 

  del(id){
    console.log(id);
    var obj, func;
    func= 'users';
    obj = {
      "id": id
    }

    this.apiCtrl.delete(func, obj).subscribe((data) => {
      console.log(data);
      this.getUser();
    }, (err)=>{
      this.globalCtrl.presentToast(err, 2000);
    })
  }

}
