import { Component, OnInit } from '@angular/core';
import { 
  Validators, 
  FormBuilder, 
  FormGroup, 
  FormControl 
} from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { GlobalService } from 'src/app/services/global.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.page.html',
  styleUrls: ['./sign-in.page.scss'],
})
export class SignInPage implements OnInit {
  loginForm: FormGroup;
  userData = {
    "email": "",
    "password": ""
  }
  constructor(
    private formBuilder: FormBuilder,
    private routerCtrl: Router,
    private globalCtrl: GlobalService,
    private apiCtrl: ApiService
  ) { } 

  ionViewWillEnter(){
    this.globalCtrl.menuDisable();
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: new FormControl(''),
      password: new FormControl('')
    });
  }

  onSubmit(value){
    console.log(value);
    
    var func, obj, res;
    obj = {
      "email": value.email,
      "password": value.password
    }
    
    console.log(obj);
    func = 'login';
    this.apiCtrl.post(func, value).subscribe((data)=> {
      console.log(data);
      res = data;
      localStorage.setItem('token', res.token);
      localStorage.setItem('activeemail', value.email);
      localStorage.setItem('login_status', 'yes');
      this.routerCtrl.navigateByUrl('/home');
    }, (err) => {
      this.globalCtrl.presentToast(err, 2000);
    });
  }

}
