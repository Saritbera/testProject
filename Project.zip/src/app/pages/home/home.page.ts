import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PopoverController } from '@ionic/angular';
import { GlobalService } from 'src/app/services/global.service';
import { UserCreatePage } from '../user-create/user-create.page';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor(
    private routerCtrl: Router,
    private popOverCtrl: PopoverController,
    private globalCtrl: GlobalService
  ) {
  }

  ionViewWillEnter(){
    this.globalCtrl.menuEnable();
  }

  CreatePopover(){
		this.popOverCtrl.create({
			component: UserCreatePage,
			showBackdrop: false,			
			backdropDismiss: false
		}).then((popoverElement) => {
			popoverElement.present();
		})
	}

  logout(){
    localStorage.setItem('token', '');
    localStorage.setItem('login_status', 'no');
    localStorage.setItem('activeemail', '');
    this.routerCtrl.navigateByUrl('sign-in');
  }

  addUser(){
    console.log('add');
    this.CreatePopover();
  }

}
