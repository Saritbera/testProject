import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home.page';

// const routes: Routes = [
//   {
//     path: '',
//     component: HomePage,
//   }
// ];

const routes: Routes = [
  {
    path: 'home',
    component: HomePage,
    children: [
      {
        path: 'list',
        children: [
          { path: '', loadChildren: () => import('../user-list/user-list.module').then( m => m.UserListPageModule) }
        ]
      },
      {
        path: 'profile',
        children: [
          { path: '', loadChildren: () => import('../user-profile/user-profile.module').then( m => m.UserProfilePageModule) }
        ]
      },
      {
        path: 'settings',
        children: [
          { path: '', loadChildren: () => import('../user-settings/user-settings.module').then( m => m.UserSettingsPageModule) }
        ]
      },
      // {
      //   path: 'complete',
      //   children: [
      //     { path: '', loadChildren: () => import('../complete-order/complete-order.module').then( m => m.CompleteOrderPageModule) }
      //   ]
      // },
      { path: '', redirectTo: 'home/list', pathMatch: 'full' }
    ]
  },
  { path: '', redirectTo: 'home/list', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomePageRoutingModule {}
