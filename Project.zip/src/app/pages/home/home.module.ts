import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { HomePage } from './home.page';

import { HomePageRoutingModule } from './home-routing.module';
import { UserListPageModule } from '../user-list/user-list.module';
import { UserProfilePageModule } from '../user-profile/user-profile.module';
import { UserSettingsPageModule } from '../user-settings/user-settings.module';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HomePageRoutingModule,
    UserListPageModule,
    UserProfilePageModule,
    UserSettingsPageModule
  ],
  declarations: [HomePage]
})
export class HomePageModule {}
