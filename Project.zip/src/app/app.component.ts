import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalService } from './services/global.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(
    private routerCtrl: Router,
    private globalCtrl: GlobalService
  ) {
    this.bootlogin();
  }

  bootlogin(){
    if(localStorage.getItem('login_status') != 'yes'){
      this.routerCtrl.navigateByUrl('/sign-in');
    } else {
      this.routerCtrl.navigateByUrl('/home');
    }
  }

  pageOpen(page){
    console.log(page);
    if(page == 'logout'){
      localStorage.setItem('token', '');
      localStorage.setItem('activeemail', '');
      localStorage.setItem('login_status', 'no');
      this.routerCtrl.navigateByUrl('sign-in');
    } else {
      this.routerCtrl.navigateByUrl('home');
    }
  }
}
