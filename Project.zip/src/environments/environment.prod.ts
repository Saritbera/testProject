export const environment = {
  production: true,
  apiendpoint: 'https://reqres.in/api/',
};
