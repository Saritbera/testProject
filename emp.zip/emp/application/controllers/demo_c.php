<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class demo_c extends CI_Controller {

        public function index() {
            //echo base_url('path');
            $this->load->view('header');
            $this->load->view('login');
            $this->load->view('footer');
        }

    }
?>