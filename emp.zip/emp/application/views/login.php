    <!-- Body of Page  -->

    <body>
        <div style="position: absolute; left:25%;top:50%;right:25%">
            <form method="post"">
                <div style="padding: 10px">
                    <div><span>User Type (admin/employee): </span><input id="log" type="text" required/><div>
                    <div>('a' for admin, 'e'  for employee)</div>
                    <div><button class="btn btn-primary" onclick="login()">Login User</button></div>
                </div>
            <form>
        </div>
    </body>