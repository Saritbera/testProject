    <!-- <script src="<?php echo base_url('asstes/js/script.js'); ?>"></script> -->
    

    <script>
            var type;
            function login() {
                type = document.getElementById("log").value;
                alert("login");
                alert(type);

                if (type == 'a' || type == 'A' || type == 'e' || type == 'E'){
                    
                } else {
                    alert('Invalid Cadential');
                }
            }
        </script>

    <!-- <scripyt></script> -->
</html>