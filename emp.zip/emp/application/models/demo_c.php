<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class demo_c extends CI_Model {

        public function getemployee() {
            
        }

    }
?>