-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2023 at 01:15 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sarit`
--

-- --------------------------------------------------------

--
-- Table structure for table `sa_department`
--

CREATE TABLE `sa_department` (
  `departmentID` varchar(10) NOT NULL,
  `departmentname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sa_employee`
--

CREATE TABLE `sa_employee` (
  `employeeID` varchar(10) NOT NULL,
  `employee name` varchar(50) DEFAULT NULL,
  `departmentID` varchar(10) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `employee_type` varchar(8) DEFAULT NULL,
  `email` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sa_department`
--
ALTER TABLE `sa_department`
  ADD PRIMARY KEY (`departmentID`);

--
-- Indexes for table `sa_employee`
--
ALTER TABLE `sa_employee`
  ADD PRIMARY KEY (`employeeID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
